
<!DOCTYPE hmtl>
<html>
<head>
	
	<title>
	Some
	</title>
</head>
<body>

<form action="insert.php" method = "POST" />
<p> Input 1: <input type="text" name="input1" / ></p>
<p> Input 2: <input type="text" name="input2" / ></p>
<p> Input 3: <input type="text" name="input3" / ></p>
<input type="submit" value = "Submit"/>
</form>

</body>

</html>