<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		
		<title></title>
	</head>
	<body>
		
		<?php
        include("Config.php");

		if ($conn->connect_error) {
			die("Connection failed: " . $conn->connect_error);
		} 
		echo "Connected successfully";
        
      $sql = "INSERT INTO user (userID, userName, userPasseword)
VALUES (14, 'name', 'web')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
		?>
	</body>
</html>