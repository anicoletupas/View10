
<?php
    include("Config.php");

if($conn === false){
   die("ERROR: Could not connect. " . mysqli_connect_error());
}
// Escape user inputs for security
$id = mysqli_real_escape_string($conn, $_POST['input1']);
$idINT = (int)$id;
$name = mysqli_real_escape_string($conn, $_POST['input2']);
$pass = mysqli_real_escape_string($conn, $_POST['input3']);
// attempt insert query execution
$sql = "INSERT INTO user (userID, userName, userPasseword) VALUES ('$idINT', '$name', '$pass')";
if(mysqli_query($conn, $sql)){
   echo "Data successfully Saved.";
} else{
   echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);
}
// close connection
mysqli_close($conn);
 

 

?>
